# DHL Shipment PDF Downloader (macOS)

Experimental Python/Playwright script for downloading shipment-detail PDFs from the DHL Business Customer Portal. **Not affiliated with DHL.**

## Current status

**Needs debugging:** On the June 2026 international-shipment results page, DHL displays 323 shipments, but the script prints `Processed 0 new PDFs. 0 currently rendered rows.` No PDFs were downloaded in that run.

Likely issue: `download_dhl.py` looks for HTML `tr` elements containing a shipment number matching `CC\d+DE`. The DHL shipment list may use a different DOM structure or dynamic loading. This is a hypothesis, not yet verified with browser DOM inspection. The script may also miss shipment numbers not matching the pattern.

## Workflow intended

1. Open DHL Business Customer Portal in a dedicated Chrome profile.
2. Log in manually and navigate to Track & trace → Shipment list.
3. Filter June 1–30, 2026, excluding Germany.
4. Expand each shipment, click **Shipment details as PDF**, then **Without Delivery Details**.
5. Save PDF as `<shipment-number>.pdf` under `~/Documents/DHL/2026/June/` and log results to CSV.

## Requirements

- macOS, Python 3, Google Chrome, internet access, DHL Business Customer Portal account
- Playwright Python package

## Run

```bash
bash Run.command
```

The launcher creates a `.venv`, installs Playwright and Chromium, and runs the script. The Python script uses installed Google Chrome (`channel='chrome'`).

## Review notes

- Inspect DHL's actual row markup/locators and whether the script is attached to the correct browser page.
- Replace brittle `tr` and `CC\d+DE` assumptions with robust selectors.
- Verify pagination/virtual scrolling, expanding/collapsing rows, download event handling, and error recovery.
- Consider making the month and output path configurable.
- Test on a few shipments before running a full batch.

## Privacy

Do not commit your Chrome profile (`~/.dhl_downloader_chrome`), PDF receipts, CSV logs, customer names/addresses, session cookies, or login credentials. The repository contains only the original script and launcher plus documentation.
