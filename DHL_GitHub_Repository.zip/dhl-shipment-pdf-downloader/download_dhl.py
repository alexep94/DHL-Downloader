from pathlib import Path
import csv, re, sys
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

OUT = Path.home() / 'Documents' / 'DHL' / '2026' / 'June'
OUT.mkdir(parents=True, exist_ok=True)
LOG = OUT / 'download_log.csv'

def clean(s):
    return re.sub(r'[^A-Za-z0-9_-]', '_', s or 'unknown')

def log(number, status, detail=''):
    exists = LOG.exists()
    with LOG.open('a', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        if not exists: w.writerow(['shipment_number','status','detail'])
        w.writerow([number,status,detail])

def main():
    with sync_playwright() as p:
        profile = Path.home() / '.dhl_downloader_chrome'
        browser = p.chromium.launch_persistent_context(str(profile), headless=False, accept_downloads=True, channel='chrome')
        page = browser.pages[0] if browser.pages else browser.new_page()
        page.goto('https://geschaeftskunden.dhl.de', wait_until='domcontentloaded')
        print('\nLog in if needed. Navigate to Track & trace > Shipment list.')
        print('Set 01.06.2026–30.06.2026 and select all destination countries EXCEPT Germany.')
        input('When the filtered shipment list is visible, press ENTER here... ')
        done = set()
        if LOG.exists():
            with LOG.open(newline='', encoding='utf-8') as f:
                done = {r['shipment_number'] for r in csv.DictReader(f) if r['status']=='downloaded'}
        count = 0
        # Process rendered shipment rows; scrolling may be required to load more.
        while True:
            rows = page.locator('tr').filter(has=page.get_by_text(re.compile(r'CC\d+DE')))
            total = rows.count()
            progressed = False
            for i in range(total):
                row = rows.nth(i)
                match = re.search(r'CC\d+DE', row.inner_text())
                if not match: continue
                number = match.group()
                if number in done or (OUT / f'{number}.pdf').exists(): continue
                try:
                    row.locator('button, [role="button"]').last.click(timeout=5000)
                    page.get_by_text('Shipment details as PDF', exact=False).last.click(timeout=5000)
                    with page.expect_download(timeout=20000) as event:
                        page.get_by_role('button', name='Without Delivery Details').click()
                    event.value.save_as(OUT / f'{clean(number)}.pdf')
                    log(number,'downloaded')
                    done.add(number); count += 1; progressed = True
                    print('Saved', number)
                except Exception as exc:
                    log(number,'failed',str(exc)[:180])
                    print('Could not process', number, str(exc)[:120])
                    input('Fix the page manually if needed, then press ENTER to continue... ')
            print(f'Processed {count} new PDFs. {total} currently rendered rows.')
            answer = input('Scroll/load more shipments in Chrome, then ENTER to continue; type q to finish: ').strip().lower()
            if answer == 'q': break
        browser.close()
        print('Files saved to:', OUT)

if __name__ == '__main__':
    main()
