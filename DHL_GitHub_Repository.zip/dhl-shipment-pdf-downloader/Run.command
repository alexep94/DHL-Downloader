#!/bin/bash
cd "$(dirname "$0")" || exit 1
python3 -m venv .venv || exit 1
source .venv/bin/activate
python -m pip install --quiet playwright || exit 1
python -m playwright install chromium || exit 1
python download_dhl.py
