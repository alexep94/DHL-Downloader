# Bug: Shipment list not detected

**Environment:** macOS, Chrome, Python 3, Playwright, DHL Business Customer Portal.

**Steps to reproduce:**
1. Run `bash Run.command`.
2. Log into DHL in the Chrome window launched by the script.
3. Navigate to Track & trace → Shipment list.
4. Set 01.06.2026–30.06.2026 and select all destination countries except Germany.
5. Confirm that 323 shipments appear, then press Enter in Terminal.

**Actual:** `Processed 0 new PDFs. 0 currently rendered rows.`

**Expected:** Script detects the shipment rows, expands each one, and downloads a shipment-details PDF without delivery details.

**Suspected code:** `page.locator('tr').filter(has=page.get_by_text(re.compile(r'CC\d+DE')))`.

**Requested investigation:** Inspect real DHL DOM and frame structure, correct selectors and loading/pagination logic, and test safely with a small sample.

**Privacy:** Do not post authenticated URLs, cookies, customer information, or unredacted screenshots in public issues.
